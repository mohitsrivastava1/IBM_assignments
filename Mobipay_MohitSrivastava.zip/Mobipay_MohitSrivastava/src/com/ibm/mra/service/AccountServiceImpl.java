package com.ibm.mra.service;

import com.ibm.mra.beans.Account;
import com.ibm.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService { 
	
	Account account = null;
	AccountDaoImpl dao = new AccountDaoImpl();
	
//	public Account getAccountDetails(String mobileno){
//		
//		return account.getAccountType();
//	}
//	
	
	public int rechargeAccount(String mobileNo, double rechargeAmount){
		return 0;
		
	}

	public double getBalance(String mobileNo) {

		return dao.getBalance(mobileNo);
	}


	public boolean mobileExists(String mobileNo) {
		
		return dao.mobileExists(mobileNo);
	} 
}
